package rocket.station.exceptions;

public class BoostException extends RuntimeException{

	public BoostException(String message) {
		super(message);
	}
}
